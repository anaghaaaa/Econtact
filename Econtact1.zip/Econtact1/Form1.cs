using Econtact1.econtactClasses;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Econtact1
{
    public partial class Form1 : Form
    {
        contactClass c = new contactClass();
        public Form1()
        {
            InitializeComponent();
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            //get the value from input fields
            c.FirstName = txtbfirstname.Text;
            c.LastName = txtblastname.Text;
            c.ContactNo = txtbcontactno.Text;
            c.Address = txtbaddress.Text;
            c.Gender = cmbGender.Text;

            //inserting data into database using method created in contactClass.cs
            bool success = c.Insert(c);
            if (success == true)
            {
                //successfully inserted
                MessageBox.Show("New contact successfully inserted.");
                //call the clear method
                Clear();

            }
            else
            {
                //failed to add contact
                MessageBox.Show("Failed to add new contact.Try again.");

            }
            //load data on datagrid view
            DataTable dt = c.Select();
            dgvContactList.DataSource = dt;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //load data on datagrid view
            DataTable dt = c.Select();
            dgvContactList.DataSource = dt;
        }

        private void pictureBoxexit_Click(object sender, EventArgs e)
        {
            //clicking on this button will close the applicatio
            this.Close();
        }
        //method to clear all the fields
        public void Clear()
        {
            txtbfirstname.Text = " ";
            txtblastname.Text = " ";
            txtbcontactno.Text = " ";
            txtbaddress.Text = " ";
            cmbGender.Text = " ";
            txtbcontactid.Text = " ";
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            //get data from textboxes
            c.ContactID = int.Parse(txtbcontactid.Text);
            c.FirstName = txtbfirstname.Text;
            c.LastName = txtblastname.Text;
            c.ContactNo = txtbcontactno.Text;
            c.Address = txtbaddress.Text;
            c.Gender = cmbGender.Text;
            //update data in database
            bool success = c.Update(c);
            if (success == true)
            {
                //updated successfully
                MessageBox.Show("Contact has been updated successfully.");
                //load data on datagrid view
                DataTable dt = c.Select();
                dgvContactList.DataSource = dt;
                //call clear method
                Clear();
            }
            else
            {
                //update failed
                MessageBox.Show("Failed to update contact. Try again.");
            }
        }

        private void dgvContactList_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            //get data from datagrid view and upload it to the respective texboxes
            //identify row in which mouse is clicked
            int rowIndex = e.RowIndex;
            txtbcontactid.Text = dgvContactList.Rows[rowIndex].Cells[0].Value.ToString();
            txtbfirstname.Text = dgvContactList.Rows[rowIndex].Cells[1].Value.ToString();
            txtblastname.Text = dgvContactList.Rows[rowIndex].Cells[2].Value.ToString();
            txtbcontactno.Text = dgvContactList.Rows[rowIndex].Cells[3].Value.ToString();
            txtbaddress.Text = dgvContactList.Rows[rowIndex].Cells[4].Value.ToString();
            cmbGender.Text = dgvContactList.Rows[rowIndex].Cells[5].Value.ToString();
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            //call clear method
            Clear();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            //get contact ID from application
            c.ContactID = Convert.ToInt32((txtbcontactid).Text);
            bool success = c.Delete(c);
            if (success == true)
            {
                //successfully deleted
                MessageBox.Show("Contact has been successfully deleted.");
                //load data on datagrid view
                DataTable dt = c.Select();
                dgvContactList.DataSource = dt;
                //call clear method
                Clear();

            }
            else
            {
                //deletion failed
                MessageBox.Show("Deletion of contact failed. Try again.");
            }
        }
        
        string connectionString = ConfigurationManager.ConnectionStrings["connstrng"].ConnectionString;

        private void txtbsearch_TextChanged(object sender, EventArgs e)
        {
            //get the value from textbox
            string keyword = txtbsearch.Text;
          
            SqlConnection conn = new SqlConnection(connectionString);
            //search based on firstname/lastname/address in search bar
            SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM tbl_contact WHERE FirstName LIKE '%" + keyword + "%' OR LastName LIKE '%" + keyword + "%' OR Address LIKE '%" + keyword + "%'", conn);

            DataTable dt = new DataTable();
            sda.Fill(dt);
            dgvContactList.DataSource= dt;

        }
    }
}
