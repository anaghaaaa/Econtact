﻿namespace Econtact1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            lblcontactid = new Label();
            txtbcontactid = new TextBox();
            btnadd = new Button();
            cmbGender = new ComboBox();
            pictureBoxexit = new PictureBox();
            dgvContactList = new DataGridView();
            txtbfirstname = new TextBox();
            lblfirstname = new Label();
            txtblastname = new TextBox();
            lbllastname = new Label();
            txtbcontactno = new TextBox();
            lblcontactno = new Label();
            txtbaddress = new TextBox();
            lbladdress = new Label();
            lblgender = new Label();
            lblsearch = new Label();
            lblecontact = new Label();
            txtbsearch = new TextBox();
            btnupdate = new Button();
            btndelete = new Button();
            btnclear = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBoxexit).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvContactList).BeginInit();
            SuspendLayout();
            // 
            // lblcontactid
            // 
            lblcontactid.AutoSize = true;
            lblcontactid.Font = new Font("Palatino Linotype", 12F);
            lblcontactid.Location = new Point(82, 163);
            lblcontactid.Name = "lblcontactid";
            lblcontactid.Size = new Size(111, 27);
            lblcontactid.TabIndex = 0;
            lblcontactid.Text = "Contact ID";
            // 
            // txtbcontactid
            // 
            txtbcontactid.BackColor = Color.White;
            txtbcontactid.Font = new Font("Palatino Linotype", 12F);
            txtbcontactid.Location = new Point(223, 166);
            txtbcontactid.Name = "txtbcontactid";
            txtbcontactid.ReadOnly = true;
            txtbcontactid.Size = new Size(239, 34);
            txtbcontactid.TabIndex = 1;
            // 
            // btnadd
            // 
            btnadd.BackColor = Color.Green;
            btnadd.Location = new Point(272, 591);
            btnadd.Name = "btnadd";
            btnadd.Size = new Size(94, 29);
            btnadd.TabIndex = 2;
            btnadd.Text = "Add";
            btnadd.UseVisualStyleBackColor = false;
            btnadd.Click += btnadd_Click;
            // 
            // cmbGender
            // 
            cmbGender.Font = new Font("Palatino Linotype", 12F);
            cmbGender.FormattingEnabled = true;
            cmbGender.Items.AddRange(new object[] { "Male", "Female" });
            cmbGender.Location = new Point(223, 494);
            cmbGender.Name = "cmbGender";
            cmbGender.Size = new Size(239, 35);
            cmbGender.TabIndex = 3;
            // 
            // pictureBoxexit
            // 
            pictureBoxexit.Image = (Image)resources.GetObject("pictureBoxexit.Image");
            pictureBoxexit.Location = new Point(905, 12);
            pictureBoxexit.Name = "pictureBoxexit";
            pictureBoxexit.Size = new Size(101, 89);
            pictureBoxexit.TabIndex = 4;
            pictureBoxexit.TabStop = false;
            pictureBoxexit.Click += pictureBoxexit_Click;
            // 
            // dgvContactList
            // 
            dgvContactList.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvContactList.GridColor = Color.IndianRed;
            dgvContactList.Location = new Point(545, 222);
            dgvContactList.Name = "dgvContactList";
            dgvContactList.RowHeadersWidth = 51;
            dgvContactList.Size = new Size(427, 307);
            dgvContactList.TabIndex = 5;
            dgvContactList.RowHeaderMouseClick += dgvContactList_RowHeaderMouseClick;
            // 
            // txtbfirstname
            // 
            txtbfirstname.Font = new Font("Palatino Linotype", 12F);
            txtbfirstname.Location = new Point(223, 222);
            txtbfirstname.Name = "txtbfirstname";
            txtbfirstname.Size = new Size(239, 34);
            txtbfirstname.TabIndex = 7;
            // 
            // lblfirstname
            // 
            lblfirstname.AutoSize = true;
            lblfirstname.Font = new Font("Palatino Linotype", 12F);
            lblfirstname.Location = new Point(82, 219);
            lblfirstname.Name = "lblfirstname";
            lblfirstname.Size = new Size(113, 27);
            lblfirstname.TabIndex = 6;
            lblfirstname.Text = "First Name";
            // 
            // txtblastname
            // 
            txtblastname.Font = new Font("Palatino Linotype", 12F);
            txtblastname.Location = new Point(223, 278);
            txtblastname.Name = "txtblastname";
            txtblastname.Size = new Size(239, 34);
            txtblastname.TabIndex = 9;
            // 
            // lbllastname
            // 
            lbllastname.AutoSize = true;
            lbllastname.Font = new Font("Palatino Linotype", 12F);
            lbllastname.Location = new Point(82, 275);
            lbllastname.Name = "lbllastname";
            lbllastname.Size = new Size(110, 27);
            lbllastname.TabIndex = 8;
            lbllastname.Text = "Last Name";
            // 
            // txtbcontactno
            // 
            txtbcontactno.Font = new Font("Palatino Linotype", 12F);
            txtbcontactno.Location = new Point(223, 335);
            txtbcontactno.Name = "txtbcontactno";
            txtbcontactno.Size = new Size(239, 34);
            txtbcontactno.TabIndex = 11;
            // 
            // lblcontactno
            // 
            lblcontactno.AutoSize = true;
            lblcontactno.Font = new Font("Palatino Linotype", 12F);
            lblcontactno.Location = new Point(82, 335);
            lblcontactno.Name = "lblcontactno";
            lblcontactno.Size = new Size(120, 27);
            lblcontactno.TabIndex = 10;
            lblcontactno.Text = "Contact No.";
            // 
            // txtbaddress
            // 
            txtbaddress.Font = new Font("Palatino Linotype", 12F);
            txtbaddress.Location = new Point(223, 388);
            txtbaddress.Multiline = true;
            txtbaddress.Name = "txtbaddress";
            txtbaddress.Size = new Size(239, 89);
            txtbaddress.TabIndex = 13;
            // 
            // lbladdress
            // 
            lbladdress.AutoSize = true;
            lbladdress.Font = new Font("Palatino Linotype", 12F);
            lbladdress.Location = new Point(82, 395);
            lbladdress.Name = "lbladdress";
            lbladdress.Size = new Size(88, 27);
            lbladdress.TabIndex = 12;
            lbladdress.Text = "Address";
            // 
            // lblgender
            // 
            lblgender.AutoSize = true;
            lblgender.Font = new Font("Palatino Linotype", 12F);
            lblgender.Location = new Point(82, 494);
            lblgender.Name = "lblgender";
            lblgender.Size = new Size(79, 27);
            lblgender.TabIndex = 14;
            lblgender.Text = "Gender";
            // 
            // lblsearch
            // 
            lblsearch.AutoSize = true;
            lblsearch.Font = new Font("Palatino Linotype", 12F);
            lblsearch.Location = new Point(545, 166);
            lblsearch.Name = "lblsearch";
            lblsearch.Size = new Size(72, 27);
            lblsearch.TabIndex = 15;
            lblsearch.Text = "Search";
            // 
            // lblecontact
            // 
            lblecontact.AutoSize = true;
            lblecontact.Font = new Font("Papyrus", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblecontact.Location = new Point(425, 28);
            lblecontact.Name = "lblecontact";
            lblecontact.Size = new Size(196, 64);
            lblecontact.TabIndex = 16;
            lblecontact.Text = "Econtact";
            // 
            // txtbsearch
            // 
            txtbsearch.Font = new Font("Palatino Linotype", 12F);
            txtbsearch.Location = new Point(633, 166);
            txtbsearch.Name = "txtbsearch";
            txtbsearch.Size = new Size(328, 34);
            txtbsearch.TabIndex = 17;
            txtbsearch.TextChanged += txtbsearch_TextChanged;
            // 
            // btnupdate
            // 
            btnupdate.BackColor = Color.Teal;
            btnupdate.Location = new Point(395, 591);
            btnupdate.Name = "btnupdate";
            btnupdate.Size = new Size(94, 29);
            btnupdate.TabIndex = 18;
            btnupdate.Text = "Update";
            btnupdate.UseVisualStyleBackColor = false;
            btnupdate.Click += btnupdate_Click;
            // 
            // btndelete
            // 
            btndelete.BackColor = Color.FromArgb(192, 0, 0);
            btndelete.Location = new Point(527, 591);
            btndelete.Name = "btndelete";
            btndelete.Size = new Size(94, 29);
            btndelete.TabIndex = 19;
            btndelete.Text = "Delete";
            btndelete.UseVisualStyleBackColor = false;
            btndelete.Click += btndelete_Click;
            // 
            // btnclear
            // 
            btnclear.BackColor = Color.FromArgb(255, 128, 0);
            btnclear.Location = new Point(663, 591);
            btnclear.Name = "btnclear";
            btnclear.Size = new Size(94, 29);
            btnclear.TabIndex = 20;
            btnclear.Text = "Clear";
            btnclear.UseVisualStyleBackColor = false;
            btnclear.Click += btnclear_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1018, 672);
            Controls.Add(btnclear);
            Controls.Add(btndelete);
            Controls.Add(btnupdate);
            Controls.Add(txtbsearch);
            Controls.Add(lblecontact);
            Controls.Add(lblsearch);
            Controls.Add(lblgender);
            Controls.Add(txtbaddress);
            Controls.Add(lbladdress);
            Controls.Add(txtbcontactno);
            Controls.Add(lblcontactno);
            Controls.Add(txtblastname);
            Controls.Add(lbllastname);
            Controls.Add(txtbfirstname);
            Controls.Add(lblfirstname);
            Controls.Add(dgvContactList);
            Controls.Add(pictureBoxexit);
            Controls.Add(cmbGender);
            Controls.Add(btnadd);
            Controls.Add(txtbcontactid);
            Controls.Add(lblcontactid);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBoxexit).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvContactList).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblcontactid;
        private TextBox txtbcontactid;
        private Button btnadd;
        private ComboBox cmbGender;
        private PictureBox pictureBoxexit;
        private DataGridView dgvContactList;
        private TextBox txtbfirstname;
        private Label lblfirstname;
        private TextBox txtblastname;
        private Label lbllastname;
        private TextBox txtbcontactno;
        private Label lblcontactno;
        private TextBox txtbaddress;
        private Label lbladdress;
        private Label lblgender;
        private Label lblsearch;
        private Label lblecontact;
        private TextBox txtbsearch;
        private Button btnupdate;
        private Button btndelete;
        private Button btnclear;
    }
}
